﻿using System;
using System.Collections.Generic;

namespace capstone7.Data
{
    public partial class CategorySalesFor1997
    {
        public string CategoryName { get; set; }
        public decimal? CategorySales { get; set; }
    }
}
